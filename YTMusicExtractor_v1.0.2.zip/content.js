// manifest.jsonで定義されているため必要に応じて自動読み込みされます
// 今回はpopup.jsから動的に注入する形式をとっているため空でも動作します
console.log('YT Music Extractor Content Script Loaded');

